#ifndef DFRobotDFPlayerMini_h
#define DFRobotDFPlayerMini_h

#include "Arduino.h"
#include "SoftwareSerial.h"

class DFRobotDFPlayerMini
{
public:
  DFRobotDFPlayerMini();

  void begin(Stream &stream);
  void play(int fileNumber);
  void volume(uint8_t volume);

private:
  Stream* _serial;
};

#endif
