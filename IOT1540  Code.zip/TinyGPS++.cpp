#include "TinyGPS++.h"

void TinyGPSPlus::encode(char c)
{
  if (c == '$') {
    _termIndex = 0;
  } else if (c == ',' || c == '*') {
    parse(c);
    _termIndex = 0;
  } else if (_termIndex < sizeof(_term) - 1) {
    _term[_termIndex++] = c;
  }
}

void TinyGPSPlus::parse(char c)
{
  _term[_termIndex] = 0;
  if (_term[0] == 'G' && _term[1] == 'P' && _term[2] == 'G' && _term[3] == 'G' && _term[4] == 'A') {
    // Simple parsing logic for GPGGA sentence (latitude and longitude extraction)
    char *p = _term + 5;
    while (*p) {
      if (*p == ',') break;
      p++;
    }
    if (*p == ',') {
      *p++ = 0;
      _lat = atof(_term + 5);
    }
    while (*p) {
      if (*p == ',') break;
      p++;
    }
    if (*p == ',') {
      *p++ = 0;
      _lng = atof(p);
    }
    location.set(_lat, _lng);
  }
}
