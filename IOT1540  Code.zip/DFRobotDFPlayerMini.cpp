#include "DFRobotDFPlayerMini.h"

DFRobotDFPlayerMini::DFRobotDFPlayerMini()
{
}

void DFRobotDFPlayerMini::begin(Stream &stream)
{
  _serial = &stream;
}

void DFRobotDFPlayerMini::play(int fileNumber)
{
  _serial->write((uint8_t)0x7E);
  _serial->write((uint8_t)0xFF);
  _serial->write((uint8_t)0x06);
  _serial->write((uint8_t)0x03);
  _serial->write((uint8_t)0x00);
  _serial->write((uint8_t)0x00);
  _serial->write((uint8_t)fileNumber);
  _serial->write((uint8_t)0xEF);
}

void DFRobotDFPlayerMini::volume(uint8_t volume)
{
  _serial->write((uint8_t)0x7E);
  _serial->write((uint8_t)0xFF);
  _serial->write((uint8_t)0x06);
  _serial->write((uint8_t)0x06);
  _serial->write((uint8_t)0x00);
  _serial->write((uint8_t)0x00);
  _serial->write((uint8_t)volume);
  _serial->write((uint8_t)0xEF);
}
