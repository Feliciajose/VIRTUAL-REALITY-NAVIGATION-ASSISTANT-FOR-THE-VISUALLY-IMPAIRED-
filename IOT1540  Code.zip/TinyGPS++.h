#ifndef TinyGPSPlus_h
#define TinyGPSPlus_h

#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

class TinyGPSLocation
{
public:
  bool isUpdated() const { return _updated; }
  bool isValid() const { return _valid; }
  double lat() const { return _lat; }
  double lng() const { return _lng; }
  void set(double lat, double lng) { _lat = lat; _lng = lng; _updated = true; _valid = true; }

private:
  bool _valid = false, _updated = false;
  double _lat, _lng;
};

class TinyGPSPlus
{
public:
  TinyGPSPlus() {}
  void encode(char c);
  TinyGPSLocation location;

private:
  void parse(char c);
  double _lat, _lng;
  char _term[15];
  unsigned char _termIndex = 0;
};

#endif // TinyGPSPlus_h
